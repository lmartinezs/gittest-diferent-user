<?php

ini_set('memory_limit', '3000M'); // or you could use 1G
ini_set('max_execution_time', 0);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

define('WP_USE_THEMES', false);
define('WP_MEMORY_LIMIT', '3000M');
define('WP_IMPORTING', true);

error_reporting(E_ALL);

/** Loads the WordPress Environment and Template */
require './wp-blog-header.php';

if (!isset($wp_did_header)) {

    $wp_did_header = true;

    require_once dirname(__FILE__) . '/wp-load.php';
    require_once( ABSPATH . '/wp-admin/includes/taxonomy.php');

    wp();
    require_once ABSPATH . WPINC . '/template-loader.php';
}

date_default_timezone_set('America/Mexico_City');

$is_article = true;

$opts = array('http' => array('header' => 'Accept-Charset: UTF-8, *;q=0'));

$context = stream_context_create($opts);

$json = file_get_contents("./episodes7.json", false, $context);

$json = htmlentities($json, null, "UTF-8");

$data = json_encode($json);

$data = json_decode($data, true, 2);

$data = json_decode($data);

if (!is_array($data)) {
    $is_article = false;

}

$i=0;
foreach ($data as $articles) {

    if($articles->link != ''){
            echo '#' . $i . ' | ' . html_entity_decode($articles->title). '
        ';

            $title = html_entity_decode($articles->title);            
            $description = html_entity_decode($articles->description);
            $slug = basename($articles->link);
            
            $publish_date = $articles->pubDate;
            $creator = $articles->creator;
            $content = $articles->content;
            $enclosureUrl = $articles->enclosure->url;
            $enclosureLength= $articles->enclosure->length;
            $enclosureType = $articles->enclosure->type;
            $image = $articles->image;
            $explicit = $articles->explicit;
            $duration = $articles->duration;
            $author = $articles->author;
            $podcastId = $articles->podastId;
            
            $typeEpisode = current(explode("/",$enclosureType));
            
            ///--------------------------------------
            ///
            /// PREPARE TO INSERT WP :)
            ///
            ///--------------------------------------
            
            $args = array(
                    'hide_empty' => false, // also retrieve terms which are not used yet
                    'taxonomy'  => 'series',
                    'meta_query' => array(
                            array(
                            'key'       => '_migration_category_id',
                            'value'     => $podcastId,
                            'compare'   => '='
                            )
                    )
            );
            $terms = get_terms( $args );
            //ID Serie Default : 23 (Noticieros Televisa)
            //ID Author Default : 2(Noticieros Televisa)
            $term_id = 11;
            $author_id = 12;

            //Assign Speakers
            //$id_speakers = array(20);
            $speakers_lahoradeopinar = array("Leo Zuckermann","Héctor Aguilar Camín", "Jorge Castañeda", "Denise Dresser", "Gerardo Esquivel", "Juan Pardinas", "Luis de la Calle","Andrés Antonius");
            $speakers_tercergrado = array("Leopoldo Gómez","Carlos Loret de Mola", "Joaquín López Dóriga", "Leo Zuckermann", "René Delgado", "Raymundo Riva Palacio", "Denise Maerker");
            
            $id_speakers = array("Noticieros Televisa");
            
            //La hora de opinar
            if($podcastId == "308303"){
                $id_speakers = $speakers_lahoradeopinar;
		$term_id = 17;
            }
            //Tercer Grado
            if($podcastId == "889720"){
                $id_speakers = $speakers_tercergrado;
		$term_id = 12;
            }
            
           /* if(isset($terms[0])){
                $term_id = $terms[0]->term_id;
            }*/     
            //print_r($term_id); die;
            // Post filtering
            remove_filter('content_save_pre', 'wp_filter_post_kses');
            remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');
            $defaults = array(
                'post_date' => $publish_date,
                'post_modified' => $publish_date,
                'post_author' => $author_id,
                'post_name' => $slug,
                'post_content' => html_entity_decode($content, ENT_HTML5, 'UTF-8'),
                'post_title' => $title,
                'post_excerpt' => $description,
                'post_status' => 'publish',
                'post_type' => 'podcast',        
                //'post_category' => array($term_id),
                'import_id' => 0,
            );

            
            //print_r($defaults); die;
            $wp_error = true;
            $id_insert = 0;

            if ($is_article && $articles->link  != '') {
                //echo html_entity_decode($title, ENT_HTML5, 'UTF-8');               
                wp_defer_term_counting(true);
                wp_defer_comment_counting(true);
                $wpdb->query('SET autocommit = 0;');
                //prin_r($id_insert);
                $id_insert = wp_insert_post($defaults, $wp_error);        
                
                //Assign Serie
                $term_taxonomy_ids = wp_set_object_terms( $id_insert, array($term_id), 'series' );

               

                wp_set_object_terms( $id_insert, $id_speakers, 'speaker' );
                
                add_post_meta($id_insert, 'episode_type', $typeEpisode);
                add_post_meta($id_insert, 'audio_file', $enclosureUrl);
                add_post_meta($id_insert, 'enclosure', $enclosureUrl);
                add_post_meta($id_insert, 'duration', $duration);
                add_post_meta($id_insert, 'date_recorded', $publish_date);
                add_post_meta($id_insert, '_migrated_id', sanitize_title($title));

                add_post_meta($id_insert, 'filesize', isa_convert_bytes_to_specified($enclosureLength, 'M') . "MB");

                echo set_image($id_insert, $articles);

                //add_post_meta($id_insert, 'filesize', $typeEpisode);  
                # meta_id, post_id, meta_key, meta_value
                $wpdb->query('COMMIT;');

                wp_defer_term_counting(false);
                wp_defer_comment_counting(false);

                // Post filtering
                add_filter('content_save_pre', 'wp_filter_post_kses');
                add_filter('content_filtered_save_pre', 'wp_filter_post_kses');            

            }
	    ++$i;
            //if (++$i == 2) break;
    }

}

function getFileSize($url){
    $ch = curl_init(); 
    curl_setopt($ch, CURLOPT_HEADER, true); 
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
    curl_setopt($ch, CURLOPT_URL, $url); //specify the url
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
    $head = curl_exec($ch);

    $size = curl_getinfo($ch,CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    return $size;
    //return isa_convert_bytes_to_specified($size, 'M');
}

function isa_convert_bytes_to_specified($bytes, $to, $decimal_places = 1) {
    $formulas = array(
        'K' => number_format($bytes / 1024, $decimal_places),
        'M' => number_format($bytes / 1048576, $decimal_places),
        'G' => number_format($bytes / 1073741824, $decimal_places)
    );
    return isset($formulas[$to]) ? $formulas[$to] : 0;
}

function set_image($post_id, $post){
        global $wpdb;
        $img = $wpdb->get_results("SELECT post_id FROM wp_postmeta WHERE meta_key = '_original_BSImageUrl' AND meta_value = '".$post->image."'");
            
        //Si la imagen ya existe
        if(!empty($img)){
           echo "Ya existe, asignando... ". $post->$image ."\n";
            $attach_id = $img[0]->post_id;
            set_post_thumbnail( $post_id, $attach_id );
        }else{
            $url = strtok($post->image, '?');
            $image_name       = basename($url);//$post->title;
            $upload_dir       = wp_upload_dir(); // Set upload folder
            /*print_r($post);
            echo $post->image;
            $url = strtok($post->image, '?');
            echo $url;die;*/
            $image_data       = file_get_contents($post->image); // Get image data
            
            $unique_file_name = wp_unique_filename( $upload_dir['path'], $image_name ); // Generate unique name
            $filename         = basename( remove_accents(strtolower($unique_file_name)) ); // Create image file name
            $filename = preg_replace("/[^a-zA-Z0-9-]+/", "", $filename);

            // Check folder permission and define file location
            if( wp_mkdir_p( $upload_dir['path'] ) ) {
                $file = $upload_dir['path'] . '/' . $filename . ".jpg";
            } else {
                $file = $upload_dir['basedir'] . '/' . $filename . ".jpg";
            }

            // Create the image  file on the server
            file_put_contents( $file, $image_data );
            // Check image file type
            $wp_filetype = wp_check_filetype( $filename, null );

            // Set attachment data
            $attachment = array(
                'post_mime_type' => 'image/jpg',
                'post_title'     => sanitize_file_name( $filename ),        
                'post_status'    => 'inherit'
            );

            // Include image.php
            require_once(ABSPATH . 'wp-admin/includes/image.php');

            //echo  $post->post_title.' | '.$file . "\n";

            // Create the attachment
            $attach_id = wp_insert_attachment( $attachment, $file, $post_id );

            // Define attachment metadata
            $attach_data = wp_generate_attachment_metadata( $attach_id, $file );

            // Assign metadata to attachment
            wp_update_attachment_metadata( $attach_id, $attach_data );
            
            update_post_meta( $attach_id, '_original_BSImageUrl',  $post->image);

            // And finally assign featured image to post
            set_post_thumbnail( $post_id, $attach_id );
        }
}

?>

